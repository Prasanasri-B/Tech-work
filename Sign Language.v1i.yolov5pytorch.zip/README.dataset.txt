# Sign Language > 2024-12-16 7:21am
https://universe.roboflow.com/sign-language-f0hwd/sign-language-cqikh

Provided by a Roboflow user
License: CC BY 4.0

